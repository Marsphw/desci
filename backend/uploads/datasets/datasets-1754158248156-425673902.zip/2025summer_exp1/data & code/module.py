import numpy as np

class Conv2d:
    def __init__(self, in_channels: int, out_channels: int, kernel_size: int, 
                 stride: int = 1, padding: int = 0, dtype = None):
        # ------------------------------请完成此部分内容------------------------------
    
    
        # ---------------------------------------------------------------------------

    def forward(self, x):
        """
        x - shape (N, C, H, W)
        return the result of Conv2d with shape (N, O, H', W')
        """
       # ------------------------------请完成此部分内容------------------------------
    
    
        # ---------------------------------------------------------------------------

    def backward(self, dy, lr):
        """
        dy - the gradient of last layer with shape (N, O, H', W')
        lr - learning rate
        calculate self.w_grad to update self.weight,
        calculate self.b_grad to update self.bias,
        return the result of gradient dx with shape (N, C, H, W)
        """
       # ------------------------------请完成此部分内容------------------------------
    

    
        # ---------------------------------------------------------------------------
    

     

class ReLU:
    def forward(self, x):
      
    def backward(self, dy):
       

class Tanh:
    def forward(self, x):
       

    def backward(self, dy):
        
class Sigmoid:
    def forward(self, x):
       
    def backward(self, dy):
       
class MaxPool2d:
    def __init__(self, kernel_size: int, stride = None, padding = 0):
      

    def forward(self, x):
        """
        x - shape (N, C, H, W)
        return the result of MaxPool2d with shape (N, C, H', W')
        """
       

    def backward(self, dy):
        """
        dy - shape (N, C, H', W')
        return the result of gradient dx with shape (N, C, H, W)
        """
     
class AvgPool2d:
    def __init__(self, kernel_size: int, stride = None, padding = 0):
       
    def forward(self, x):
        """
        x - shape (N, C, H, W)
        return the result of AvgPool2d with shape (N, C, H', W')
        """
       

    def backward(self, dy):
        """
        dy - shape (N, C, H', W')
        return the result of gradient dx with shape (N, C, H, W)
        """
       
        

class Linear:
    def __init__(self, in_features: int, out_features: int, bias: bool = True):
        
        

    def forward(self, x):
        """
        x - shape (N, C)
        return the result of Linear layer with shape (N, O)
        """
       


    def backward(self, dy, lr):
        """
        dy - shape (N, O)
        return the result of gradient dx with shape (N, C)
        """
        

class CrossEntropyLoss:
    def __call__(self, x, label):
       
        